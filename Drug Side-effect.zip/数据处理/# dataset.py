# dataset.py
import pandas as pd
from graph_utils import build_molecular_graph
from descriptors import get_descriptors

def load_data(file_path):
    data = pd.read_csv(file_path, index_col=0)
    return data

def prepare_dataset(data, start, end):
    smiles_list = data.iloc[start:end, 0]
    graphs = []
    for smiles in smiles_list:
        rdkit_data = get_descriptors(smiles).values[0]
        graphs.append(build_molecular_graph(smiles, rdkit_data))
    return graphs
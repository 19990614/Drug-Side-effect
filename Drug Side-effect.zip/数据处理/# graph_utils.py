# graph_utils.py
import dgl
from rdkit import Chem
from descriptors import get_descriptors
from features import get_atom_features, get_bond_features

def build_molecular_graph(smiles, rdkit_data):
    G = dgl.DGLGraph()
    molecule = Chem.AddHs(Chem.MolFromSmiles(smiles))
    num_atoms = molecule.GetNumAtoms()
    G.add_nodes(num_atoms)

    node_features = []
    edge_features = []

    for i in range(num_atoms):
        atom = molecule.GetAtomWithIdx(i)
        node_features.append(get_atom_features(atom, rdkit_data))
        for j in range(num_atoms):
            bond = molecule.GetBondBetweenAtoms(i, j)
            if bond:
                G.add_edges(i, j)
                edge_features.append(get_bond_features(bond))

    G.ndata['x'] = np.array(node_features, dtype=np.float32)
    G.edata['w'] = np.array(edge_features, dtype=np.float32)
    return G
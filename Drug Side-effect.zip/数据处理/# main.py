# main.py
import numpy as np
import torch
from dataset import load_data, prepare_dataset

def main():
    data_file = "path/to/XXX.csv"
    save_dir = "./PATH"

    # Load data
    data = load_data(data_file)

    # Prepare datasets
    train_graphs = prepare_dataset(data, 0, 1800)
    test_graphs = prepare_dataset(data, 1800, 2500)

    # Save datasets
    np.save(f"{save_dir}/PXR.npy", train_graphs)
    np.save(f"{save_dir}/test-PXR.npy", test_graphs)

    print("Data preparation and saving completed.")

if __name__ == "__main__":
    main()
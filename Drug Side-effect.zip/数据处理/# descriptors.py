# descriptors.py
import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Descriptors
from rdkit.ML.Descriptors import MoleculeDescriptors

def get_md(mol):
    calc = MoleculeDescriptors.MolecularDescriptorCalculator([x[0] for x in Descriptors._descList])
    return np.asarray(calc.CalcDescriptors(mol))

def get_descriptors(smiles):
    smiles = str(smiles)
    data = pd.DataFrame([smiles], columns=['SMILES'])
    data['Mol'] = data['SMILES'].apply(Chem.MolFromSmiles)
    data['descriptors'] = data['Mol'].apply(get_md)
    des_list = [x[0] for x in Descriptors._descList]
    des = {des_list[i]: [t[i] for t in data['descriptors']] for i in range(len(des_list))}
    des_df = pd.DataFrame(des)
    return des_df[['BCUT2D_LOGPHI', 'BertzCT', 'fr_COO', 'LabuteASA', 'MaxAbsEStateIndex',
                   'MaxAbsPartialCharge', 'MolLogP', 'MolMR', 'PEOE_VSA6',
                   'SlogP_VSA6', 'SlogP_VSA8']]

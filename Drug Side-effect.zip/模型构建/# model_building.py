# model_building.py
import torch
from dgl.nn.pytorch import GraphConv

class GCN(torch.nn.Module):
    def __init__(self, in_feats, h_feats, num_classes):
        super(GCN, self).__init__()
        torch.manual_seed(1234)
        self.conv1 = GraphConv(in_feats, h_feats, allow_zero_in_degree=True)
        self.conv2 = GraphConv(h_feats, h_feats, allow_zero_in_degree=True)
        self.conv3 = GraphConv(h_feats, h_feats, allow_zero_in_degree=True)
        self.classify = torch.nn.Linear(h_feats, num_classes)

    def forward(self, g):
        h = g.ndata['x']
        h = self.conv1(g, h)
        h = h.relu()
        h = self.conv2(g, h)
        h = h.relu()
        h = self.conv3(g, h)
        h = h.relu()
        g.ndata['h'] = h
        hg = dgl.mean_nodes(g, 'h')
        return self.classify(hg)
# model_testing.py
import numpy as np
import torch
from sklearn.metrics import accuracy_score
from model_building import GCN

def test_model(model_path, test_graphs_path, test_labels_path, hidden_feats=36, num_classes=2):
    test_labels = np.load(test_labels_path, allow_pickle=True).tolist()
    test_graphs = np.load(test_graphs_path, allow_pickle=True).tolist()

    model = GCN(test_graphs[0].ndata['x'].shape[1], hidden_feats, num_classes)
    model.load_state_dict(torch.load(model_path))

    test_pred = []
    iter = len(test_graphs)
    with torch.no_grad():
        for i in range(iter):
            pred = torch.softmax(model(test_graphs[i]), 1)
            pred = torch.max(pred, 1)[1].view(-1)
            test_pred += pred.detach().cpu().numpy().tolist()

    accuracy = accuracy_score(test_labels, test_pred)
    print("Test accuracy: ", accuracy)
    return accuracy
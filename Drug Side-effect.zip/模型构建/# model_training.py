# model_training.py
import torch
import torch.nn as nn
from model_building import GCN

def train_model(train_graphs, train_labels, epochs=300, lr=0.015, hidden_feats=16, num_classes=2):
    model = GCN(train_graphs[0].ndata['x'].shape[1], hidden_feats, num_classes)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()

    model.train()
    iter = len(train_graphs)

    for epoch in range(epochs):
        epoch_loss = 0
        for i in range(iter):
            prediction = model(train_graphs[i])
            loss = criterion(prediction, train_labels[i])
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            epoch_loss += loss.detach().item()
        epoch_loss /= iter
        print(f'Epoch {epoch + 1}, Loss: {epoch_loss:.4f}')

    return model
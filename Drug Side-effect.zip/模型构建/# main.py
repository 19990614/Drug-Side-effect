# main.py
import numpy as np
from model_training import train_model
from model_testing import test_model

# 加载训练数据
def load_data(train_graphs_path, train_labels_path):
    train_graphs = np.load(train_graphs_path, allow_pickle=True).tolist()
    train_labels = np.load(train_labels_path, allow_pickle=True).tolist()
    return train_graphs, train_labels

def main():
    train_graphs_path = 'XXX.npy'
    train_labels_path = 'XXX.npy'
    test_graphs_path = 'XXX.npy'
    test_labels_path = 'XXX.npy'
    model_path = 'GCN-4.pkl'

    train_graphs, train_labels = load_data(train_graphs_path, train_labels_path)

    model = train_model(train_graphs, train_labels)

    torch.save(model.state_dict(), model_path)

    test_model(model_path, test_graphs_path, test_labels_path)

if __name__ == "__main__":
    main()